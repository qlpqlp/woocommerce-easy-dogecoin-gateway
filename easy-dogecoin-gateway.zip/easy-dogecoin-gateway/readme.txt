=== Plugin Name ===
Contributors: inevitable360
Donate link: https://twitter.com/inevitable360
Tags: easy dogecoin gateway, doge, dogecoin, crypto, cryptocurrency, woocommerce, ecommerce, online-store
Requires at least: 5.6
Tested up to: 5.9
Stable tag: 69.420.0
Requires PHP: 7.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Acept Dogecoin Payments using simple your Dogecoin Address without the need of any third party payment processor, banks, extra fees.

== Description ==

Acept Dogecoin Payments using simple your Dogecoin Address without the need of any third party payment processor, banks, extra fees. Your Store, your wallet, your Doge.
It uses the Google API to generate QR Codes and the CoinGecko API to convert Fiat into Dogecoin current value.

== Frequently Asked Questions ==

= What is Dogecoin? =

ogecoin is a cryptocurrency created by software engineers Billy Markus and Jackson Palmer, who decided to create a payment system as a "joke", making fun of the wild speculation in cryptocurrencies at the time. It is considered both the first "meme coin", and, more specifically, the first "dog coin"

= Is Dogecoin Money? =

Yes

== Screenshots ==

1. Dogecoin Payment option screenshot-1.png

== Changelog ==

= 420.69.0 =
* First release

Unordered list:

* Easy Dogecoin Payment Gateway
* Auto converts Fiat to Doge

Links require brackets and parenthesis:

Here's a link to [What is Dogecoin?](http://what-is-dogecoin.com/ "What is Dogecoin?")
